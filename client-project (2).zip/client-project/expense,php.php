<?php

$con=new mysqli('localhost','root','','clientproject');
if ($con->connect_errno)
{
    echo $con->connect_error;
    die();
}
else
{	 

$name = $_POST['name'];
$expense = $_POST['expense'];
$reason = $_POST['reason'];

$sql = "INSERT INTO expense (name,expense,reason)
VALUES ('$name','$expense','$reason')";

if (mysqli_query($con, $sql)) {
  header('location:expense.html');
} else {
  echo "fail";
}
mysqli_close($con);
}

?>