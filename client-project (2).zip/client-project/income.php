<?php

$con=new mysqli('localhost','root','','clientproject');
if ($con->connect_errno)
{
    echo $con->connect_error;
    die();
}
else
{	 

$name = $_POST['name'];
$birds = $_POST['birds'];
$total = $_POST['total'];
$rate = $_POST['rate'];


$sql = "INSERT INTO income (name,birds,total,rate)
VALUES ('$name','$birds','$total','$rate')";

if (mysqli_query($con, $sql)) {
  header('location:income.html');
} else {
  echo "fail";
}
mysqli_close($con);
}

?>