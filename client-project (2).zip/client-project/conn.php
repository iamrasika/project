﻿<?php

$con=new mysqli('localhost','root','','clientproject');
if ($con->connect_errno)
{
    echo $con->connect_error;
    die();
}
else
{	 

$email= $_POST['email'];
$password = $_POST['password'];


$sql = "INSERT INTO login (email,password)
VALUES ('$email','$password')";

if (mysqli_query($con, $sql)) {
  header('location:login.html');
} else {
  echo "fail";
}
mysqli_close($con);
}

?>